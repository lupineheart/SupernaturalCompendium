package com.example.supernaturalcompendium;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CreatureInfoActivity extends AppCompatActivity {
    private TextView infoName, infoDescription, infoOrigin, infoPowers;
    private ImageView infoImage;
    private Button addToFavorites, quizButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creature_info);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        infoName = findViewById(R.id.infoName);
        infoDescription = findViewById(R.id.infoDescription);
        infoOrigin = findViewById(R.id.infoOrigin);
        infoPowers = findViewById(R.id.infoPowers);
        infoImage = findViewById(R.id.infoImage);
        addToFavorites = findViewById(R.id.addToFavorites);
        quizButton = findViewById(R.id.quizButton);

        String creatureName = getIntent().getStringExtra("creature");
        Creature creature = CreatureRepository.getCreatureByName(creatureName);

        if (creature != null) {
            infoName.setText(creature.name);
            infoDescription.setText(creature.description);
            infoOrigin.setText("Origin: " + creature.origin);
            infoPowers.setText("Powers: " + creature.powers);
            infoImage.setImageResource(creature.imageResId);
        }

        addToFavorites.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("favorites", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean(creature.name, true);
            editor.apply();
            Toast.makeText(this, "This creature was added to favorites", Toast.LENGTH_SHORT).show();
        });

        quizButton.setOnClickListener(v -> {
            Intent intent = new Intent(CreatureInfoActivity.this, QuizActivity.class);
            intent.putExtra("creature", creature.name);
            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}

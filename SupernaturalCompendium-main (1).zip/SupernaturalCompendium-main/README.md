# SupernaturalCompendium
This app serves as an interactive encyclopedia for supernatural creatures like vampires, ghosts, and werewolves, and includes creature profiles, a quiz system, and user-favorite saving.

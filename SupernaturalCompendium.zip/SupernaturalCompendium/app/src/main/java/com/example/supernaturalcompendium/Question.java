package com.example.supernaturalcompendium;
import java.util.List;


public class Question {
    public String questionText;
    public List<String> options;
    public String correctAnswer;


    public Question(String questionText, List<String> options, String correctAnswer) {
        this.questionText = questionText;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }
}

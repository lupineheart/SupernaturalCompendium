package com.example.supernaturalcompendium;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.supernaturalcompendium.Creature;
import com.example.supernaturalcompendium.Question;
import java.util.Collections;
import java.util.List;


public class QuizActivity extends AppCompatActivity {
    private TextView quizTitle, quizQuestion;
    private Button option1, option2, option3, option4, submitButton, backButton;
    private List<Question> questions;
    private int currentQuestionIndex = 0;
    private int score = 0;
    private String selectedAnswer = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        quizTitle = findViewById(R.id.quizTitle);
        quizQuestion = findViewById(R.id.quizQuestion);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        submitButton = findViewById(R.id.submitButton);
        backButton = findViewById(R.id.backButton);


        String creatureName = getIntent().getStringExtra("creature");
        Creature creature = CreatureRepository.getCreatureByName(creatureName);


        if (creature == null || creature.questions == null || creature.questions.isEmpty()) {
            Toast.makeText(this, "No questions available.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }


        quizTitle.setText("Quiz: " + creature.name);
        questions = creature.questions;
        Collections.shuffle(questions);


        loadQuestion();


        View.OnClickListener optionClickListener = view -> {
            selectedAnswer = ((Button) view).getText().toString();
            option1.setEnabled(false);
            option2.setEnabled(false);
            option3.setEnabled(false);
            option4.setEnabled(false);
        };


        option1.setOnClickListener(optionClickListener);
        option2.setOnClickListener(optionClickListener);
        option3.setOnClickListener(optionClickListener);
        option4.setOnClickListener(optionClickListener);


        submitButton.setOnClickListener(v -> {
            if (selectedAnswer.isEmpty()) {
                Toast.makeText(this, "Please select an answer.", Toast.LENGTH_SHORT).show();
                return;
            }


            Question current = questions.get(currentQuestionIndex);
            if (selectedAnswer.equals(current.correctAnswer)) {
                score++;
            }


            currentQuestionIndex++;
            if (currentQuestionIndex < questions.size()) {
                selectedAnswer = "";
                enableButtons();
                loadQuestion();
            } else {
                showScore();
            }
        });


        backButton.setOnClickListener(v -> finish());
    }


    private void loadQuestion() {
        Question q = questions.get(currentQuestionIndex);
        quizQuestion.setText(q.questionText);
        option1.setText(q.options.get(0));
        option2.setText(q.options.get(1));
        option3.setText(q.options.get(2));
        option4.setText(q.options.get(3));
        enableButtons();
    }


    private void enableButtons() {
        option1.setEnabled(true);
        option2.setEnabled(true);
        option3.setEnabled(true);
        option4.setEnabled(true);
    }


    private void showScore() {
        quizQuestion.setText("You scored " + score + " out of " + questions.size() + "!");
        option1.setVisibility(View.GONE);
        option2.setVisibility(View.GONE);
        option3.setVisibility(View.GONE);
        option4.setVisibility(View.GONE);
        submitButton.setVisibility(View.GONE);
    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}

package com.example.supernaturalcompendium;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class CreaturesActivity extends AppCompatActivity {
    private LinearLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creatures);
        LinearLayout layout = findViewById(R.id.creaturesLayout);
        for (Creature creature : CreatureRepository.getAllCreatures()) {
            Button button = new Button(this);
            button.setText(creature.name);
            button.setOnClickListener(v -> {
                Intent intent = new Intent(this, CreatureInfoActivity.class);
                intent.putExtra("creature", creature.name);
                startActivity(intent);
            });
            layout.addView(button);
        }
        Button backToHomeButton = new Button(this);
        backToHomeButton.setText("Back to Home");
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 100, 0, 100); // Push it down nicely
        params.gravity = Gravity.CENTER_HORIZONTAL;

        backToHomeButton.setLayoutParams(params);
        backToHomeButton.setOnClickListener(v -> {
            Intent intent = new Intent(CreaturesActivity.this, MainActivity.class);
            startActivity(intent);
        });

        layout.addView(backToHomeButton);  // Add it AFTER the creature buttons

        container = findViewById(R.id.creaturesLayout);

    }}

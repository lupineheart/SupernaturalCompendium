package com.example.supernaturalcompendium;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Creature randomCreature;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        TextView creatureName = findViewById(R.id.creatureOfDayName);
        ImageView creatureImage = findViewById(R.id.creatureOfDayImage);
        Button browseButton = findViewById(R.id.browseButton);
        Button favoritesButton = findViewById(R.id.favoritesButton);
        List<Creature> allCreatures = CreatureRepository.getAllCreatures();
        randomCreature = allCreatures.get(new Random().nextInt(allCreatures.size()));
        creatureName.setText(randomCreature.name);
        creatureImage.setImageResource(randomCreature.imageResId);
        creatureImage.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreatureInfoActivity.class);
            intent.putExtra("creature", randomCreature.name);
            startActivity(intent);
        });
        browseButton.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, CreaturesActivity.class))
        );
        favoritesButton.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, FavoritesActivity.class))
        );
    }
}

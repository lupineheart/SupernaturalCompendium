package com.example.supernaturalcompendium;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Map;
public class FavoritesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        LinearLayout favoritesLayout = findViewById(R.id.favoritesLayout);
        Button backToHomeButton = findViewById(R.id.backToHomeButton);
        backToHomeButton.setOnClickListener(v -> {
            Intent intent = new Intent(FavoritesActivity.this, MainActivity.class);
            startActivity(intent);
        });
        SharedPreferences prefs;
        prefs = getSharedPreferences("favorites", MODE_PRIVATE);
        Map<String, ?> allFavorites = prefs.getAll();
        List<Creature> allCreatures = CreatureRepository.getAllCreatures();

        for (Creature creature : allCreatures) {
            if (allFavorites.containsKey(creature.name)) {
                Button button = new Button(this);
                button.setText(creature.name);
                button.setOnClickListener(v -> {
                    Intent intent = new Intent(this, CreatureInfoActivity.class);
                    intent.putExtra("creature", creature.name);
                    startActivity(intent);
                });
                favoritesLayout.addView(button);
            }
        }
    }
 }


package com.example.supernaturalcompendium;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CreatureRepository {
    public static List<Creature> getAllCreatures() {
        List<Creature> creatures = new ArrayList<>();


        creatures.add(new Creature(
                "Ghost",
                "Ghosts are believed to be the spirits of the deceased who linger in the physical world due to unfinished business, trauma, or a refusal to move on. They are commonly associated with haunted locations such as old houses, cemeteries, and battlefields. In folklore, ghosts possess abilities like invisibility and intangibility, allowing them to pass through walls and objects. Paranormal investigators often use EMF (Electromagnetic Field) meters to detect anomalies, as it’s theorized that spirits can disrupt electromagnetic fields. \n",
                "Global folklore",
                "Invisibility, Haunting, Emotional Influence",
                R.drawable.ghost,
                Arrays.asList(
                        new Question("Where are ghosts most often seen?",
                                Arrays.asList("Libraries", "Haunted Houses", "Caves", "Forests"),
                                "Haunted Houses"
                        ),
                        new Question("What object is believed to detect ghosts?",
                                Arrays.asList("Mirror", "Compass", "EMF Meter", "Salt Ring"),
                                "EMF Meter"
                        ),
                        new Question("Which sense is most associated with ghost detection?",
                                Arrays.asList("Sight", "Touch", "Smell", "Sound"),
                                "Sound"
                        ),
                        new Question("Which of these is often used to ward off ghosts?",
                                Arrays.asList("Garlic", "Iron", "Salt", "Amber"),
                                "Salt"
                        )
                )
        ));


        creatures.add(new Creature(
                "Vampire",
                "Vampires are undead beings that sustain themselves by consuming the blood of the living. Originating from Eastern European folklore, they are often depicted as nocturnal creatures with a fear of sunlight. Common weaknesses include garlic, holy water, and wooden stakes, which are believed to ward off or destroy them. Vampires are also said to be unable to cross running water and are repelled by religious symbols. \n",
                "European folklore",
                "Immortality, Blood-drinking, Hypnosis, Transformation",
                R.drawable.vampire,
                Arrays.asList(
                        new Question("Which material is said to kill vampires?",
                                Arrays.asList("Iron", "Gold", "Silver", "Wood"),
                                "Wood"
                        ),
                        new Question("What is a vampire's traditional weakness?",
                                Arrays.asList("Moonlight", "Sunlight", "Fire", "Salt"),
                                "Sunlight"
                        ),
                        new Question("Which shape can vampires transform into?",
                                Arrays.asList("Wolf", "Bat", "Raven", "All of the above"),
                                "All of the above"
                        ),
                        new Question("Which item is said to repel vampires?",
                                Arrays.asList("Clover", "Garlic", "Crystal", "Bread"),
                                "Garlic"
                        )
                )
        ));


        creatures.add(new Creature(
                "Werewolf",
                "Werewolves, or lycanthropes, are humans who can transform into wolves or wolf-like creatures. This transformation is traditionally linked to the full moon, a concept popularized by 20th-century cinema.  The condition is often referred to as lycanthropy. Folklore suggests that werewolves can be killed by silver weapons, a belief that has become a staple in modern depictions. \n",
                "European and Native American folklore",
                "Shapeshifting, Superhuman Strength, Enhanced Senses",
                R.drawable.werewolf,
                Arrays.asList(
                        new Question("What triggers a werewolf's transformation?",
                                Arrays.asList("Sunset", "Bloodlust", "Full Moon", "Anger"),
                                "Full Moon"
                        ),
                        new Question("Which metal is deadly to werewolves?",
                                Arrays.asList("Steel", "Gold", "Silver", "Iron"),
                                "Silver"
                        ),
                        new Question("What is the term for fear of wolves?",
                                Arrays.asList("Lupophobia", "Caninophobia", "Lycanophobia", "Theriophobia"),
                                "Lupophobia"
                        ),
                        new Question("Werewolves are said to be vulnerable to what?",
                                Arrays.asList("Garlic", "Salt", "Silver Bullets", "Roses"),
                                "Silver Bullets"
                        )
                )
        ));


        creatures.add(new Creature(
                "Dragon",
                "Dragons are legendary creatures found in various cultures, often depicted as large, serpentine beings capable of flight and breathing fire. In Western mythology, dragons are typically portrayed as malevolent, treasure-hoarding beasts. The association with hoarding gold may symbolize greed and the corrupting power of wealth.  In contrast, Eastern dragons are often seen as benevolent and wise, associated with water and rainfall.\n",
                "European and Asian mythology",
                "Fire-breathing, Flight, Magic, Immense Strength",
                R.drawable.dragon,
                Arrays.asList(
                        new Question("What is a dragon's most iconic ability?",
                                Arrays.asList("Mind Control", "Fire Breathing", "Shapeshifting", "Singing"),
                                "Fire Breathing"
                        ),
                        new Question("Which culture often depicts dragons as wise and benevolent?",
                                Arrays.asList("Norse", "Chinese", "Greek", "Slavic"),
                                "Chinese"
                        ),
                        new Question("What do dragons often hoard?",
                                Arrays.asList("Weapons", "Bones", "Gold", "Souls"),
                                "Gold"
                        ),
                        new Question("Which class of animal are dragons often associated with?",
                                Arrays.asList("Reptiles", "Mammals", "Fish", "Birds"),
                                "Reptiles"
                        )
                )
        ));


        creatures.add(new Creature(
                "Fairy",
                "Fairies are mythical beings found in European folklore, often described as small, magical creatures with human-like appearances. They are associated with nature and are believed to inhabit forests, hills, and other natural settings. Fairies are known to form “fairy rings,” which are circles of mushrooms believed to be portals to their realm. They are traditionally vulnerable to iron, particularly “cold iron,” which is thought to repel or harm them.\n",
                "Celtic mythology",
                "Illusion, Flight, Magic, Shape-shifting",
                R.drawable.fairy,
                Arrays.asList(
                        new Question("What is a common habitat for fairies?",
                                Arrays.asList("Mountains", "Lakes", "Forests", "Volcanoes"),
                                "Forests"
                        ),
                        new Question("Which item is used to see through fairy illusions?",
                                Arrays.asList("Mirror", "Iron", "Salt", "Four-leaf Clover"),
                                "Four-leaf Clover"
                        ),
                        new Question("What are fairies said to dislike?",
                                Arrays.asList("Gold", "Sunlight", "Iron", "Water"),
                                "Iron"
                        ),
                        new Question("Which court is associated with dangerous fairies?",
                                Arrays.asList("Dark Court", "Court of Shadows", "Unseelie Court", "Twilight Court"),
                                "Unseelie Court"
                        )
                )
        ));


        return creatures;
    }


    public static Creature getCreatureByName(String name) {
        for (Creature creature : getAllCreatures()) {
            if (creature.name.equalsIgnoreCase(name)) {
                return creature;
            }
        }
        return null;
    }
}


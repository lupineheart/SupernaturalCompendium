package com.example.supernaturalcompendium;
import java.util.List;


public class Creature {
    public String name;
    public String description;
    public String origin;
    public String powers;
    public int imageResId;
    public List<Question> questions;


    public Creature(String name, String description, String origin, String powers,
                    int imageResId, List<Question> questions) {
        this.name = name;
        this.description = description;
        this.origin = origin;
        this.powers = powers;
        this.imageResId = imageResId;
        this.questions = questions;
    }
}
